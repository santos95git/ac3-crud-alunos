import { criarPool } from './src/db.js';
import { criarRepositorio } from './src/repositorio.js';
import { criarApp } from './src/app.js';

let pool;
try {
  const porta = Number(process.env.PORT || 3000);
  const host = process.env.HOST || '127.0.0.1';
  if (!Number.isInteger(porta) || porta < 1 || porta > 65535) {
    throw new Error('PORT deve ser uma porta entre 1 e 65535.');
  }
  pool = criarPool();
  const repositorio = criarRepositorio(pool);
  await repositorio.verificarConexao();
  const servidor = criarApp(repositorio).listen(porta, host, () => {
    console.log('MySQL conectado.');
    console.log(`Cadastro de alunos: http://${host}:${porta}`);
    console.log('Pressione Ctrl+C para encerrar.');
  });
  servidor.on('error', async (erro) => {
    console.error(erro.code === 'EADDRINUSE' ? 'Porta em uso. Ajuste PORT no .env.' : erro.message);
    await pool.end();
    process.exitCode = 1;
  });
  const encerrar = () => {
    servidor.close(async () => {
      await pool.end();
      process.exitCode = 0;
    });
  };
  process.once('SIGINT', encerrar);
  process.once('SIGTERM', encerrar);
} catch (erro) {
  console.error('Falha ao iniciar:', erro.message);
  console.error('Confira o MySQL, os scripts de banco e as credenciais no .env.');
  if (pool) await pool.end();
  process.exitCode = 1;
}

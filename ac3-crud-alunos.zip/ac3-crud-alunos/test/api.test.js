import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { criarApp } from '../src/app.js';

// Estes testes verificam o contrato HTTP usando um repositório em memória.
// O teste com SQL real fica separado em mysql.test.js.
export function repositorioEmMemoria(iniciais = []) {
  const registros = new Map(iniciais.map((aluno) => [aluno.id, { ...aluno }]));
  let proximoId = Math.max(0, ...registros.keys()) + 1;
  function conferirEmail(email, id = null) {
    if ([...registros.values()].some((aluno) => aluno.email === email && aluno.id !== id)) {
      throw Object.assign(new Error('Duplicate entry'), { code: 'ER_DUP_ENTRY' });
    }
  }
  return {
    async verificarConexao() {},
    async listar() { return [...registros.values()].sort((a, b) => b.id - a.id); },
    async buscar(id) { return registros.get(id) || null; },
    async criar(dados) {
      conferirEmail(dados.email);
      const aluno = { id: proximoId++, ...dados };
      registros.set(aluno.id, aluno);
      return aluno;
    },
    async atualizar(id, dados) {
      if (!registros.has(id)) return false;
      conferirEmail(dados.email, id);
      registros.set(id, { id, ...dados });
      return true;
    },
    async excluir(id) { return registros.delete(id); }
  };
}

async function iniciar(t, repo = repositorioEmMemoria()) {
  const servidor = criarApp(repo, { registrarErro() {} }).listen(0, '127.0.0.1');
  await once(servidor, 'listening');
  t.after(() => new Promise((resolve, reject) => servidor.close((erro) => erro ? reject(erro) : resolve())));
  const endereco = `http://127.0.0.1:${servidor.address().port}`;
  return (caminho, opcoes = {}) => fetch(`${endereco}${caminho}`, {
    signal: AbortSignal.timeout(5000), ...opcoes
  });
}

const aluno = { nome: 'Ana Souza', email: 'ana@example.com', curso: 'Redes de Computadores' };
const json = (method, body) => ({ method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

test('CRUD completo: cria, lista, consulta, atualiza e exclui', async (t) => {
  const requisitar = await iniciar(t);
  let resposta = await requisitar('/api/alunos', json('POST', { ...aluno, nome: '  Ana Souza  ', email: 'ANA@EXAMPLE.COM' }));
  assert.equal(resposta.status, 201);
  const criado = await resposta.json();
  assert.deepEqual(criado, { id: 1, ...aluno });
  assert.equal(resposta.headers.get('location'), '/api/alunos/1');
  resposta = await requisitar('/api/alunos');
  assert.deepEqual(await resposta.json(), [criado]);
  resposta = await requisitar('/api/alunos/1');
  assert.deepEqual(await resposta.json(), criado);
  resposta = await requisitar('/api/alunos/1', json('PUT', { ...aluno, curso: 'Sistemas de Informação' }));
  assert.equal(resposta.status, 200);
  assert.equal((await resposta.json()).curso, 'Sistemas de Informação');
  resposta = await requisitar('/api/alunos/1');
  assert.equal((await resposta.json()).curso, 'Sistemas de Informação');
  resposta = await requisitar('/api/alunos/1', { method: 'DELETE' });
  assert.equal(resposta.status, 204);
  assert.equal(await resposta.text(), '');
  assert.equal((await requisitar('/api/alunos/1')).status, 404);
  assert.deepEqual(await (await requisitar('/api/alunos')).json(), []);
});

test('valida campos obrigatórios, tipos, tamanhos e formato de e-mail', async (t) => {
  const requisitar = await iniciar(t);
  for (const dados of [null, [], {}, { ...aluno, nome: '   ' }, { ...aluno, curso: 123 },
    { ...aluno, nome: 'a'.repeat(121) }, { ...aluno, curso: 'x'.repeat(101) },
    { ...aluno, email: 'a'.repeat(175) + '@example.com' }, { ...aluno, email: 'email-invalido' }]) {
    const resposta = await requisitar('/api/alunos', json('POST', dados));
    assert.equal(resposta.status, 400);
    assert.equal(typeof (await resposta.json()).erro, 'string');
  }
  assert.deepEqual(await (await requisitar('/api/alunos')).json(), []);
});

test('impede cadastro e edição com e-mail duplicado', async (t) => {
  const requisitar = await iniciar(t);
  assert.equal((await requisitar('/api/alunos', json('POST', aluno))).status, 201);
  assert.equal((await requisitar('/api/alunos', json('POST', aluno))).status, 409);
  assert.equal((await requisitar('/api/alunos', json('POST', { ...aluno, email: 'bruno@example.com' }))).status, 201);
  assert.equal((await requisitar('/api/alunos/2', json('PUT', aluno))).status, 409);
});

test('aceita salvar um aluno sem mudar os valores', async (t) => {
  const requisitar = await iniciar(t, repositorioEmMemoria([{ id: 1, ...aluno }]));
  assert.equal((await requisitar('/api/alunos/1', json('PUT', aluno))).status, 200);
});

test('rejeita IDs inválidos em consulta, edição e exclusão', async (t) => {
  const requisitar = await iniciar(t);
  for (const id of ['0', '-1', '1abc', '1e2', '4294967296']) {
    assert.equal((await requisitar(`/api/alunos/${id}`)).status, 400);
    assert.equal((await requisitar(`/api/alunos/${id}`, json('PUT', aluno))).status, 400);
    assert.equal((await requisitar(`/api/alunos/${id}`, { method: 'DELETE' })).status, 400);
  }
});

test('retorna 404 para aluno inexistente', async (t) => {
  const requisitar = await iniciar(t);
  assert.equal((await requisitar('/api/alunos/999')).status, 404);
  assert.equal((await requisitar('/api/alunos/999', json('PUT', aluno))).status, 404);
  assert.equal((await requisitar('/api/alunos/999', { method: 'DELETE' })).status, 404);
});

test('rejeita JSON inválido e corpo acima do limite', async (t) => {
  const requisitar = await iniciar(t);
  assert.equal((await requisitar('/api/alunos', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{'
  })).status, 400);
  assert.equal((await requisitar('/api/alunos', json('POST', { ...aluno, nome: 'x'.repeat(17000) }))).status, 413);
});

test('entrega a interface e mantém arquivos internos fora da pasta pública', async (t) => {
  const requisitar = await iniciar(t);
  const resposta = await requisitar('/');
  assert.equal(resposta.status, 200);
  assert.match(await resposta.text(), /Cadastro de alunos/);
  assert.match(resposta.headers.get('content-security-policy'), /script-src 'self'/);
  for (const caminho of ['/.env', '/server.js', '/banco/01-banco.sql']) {
    assert.equal((await requisitar(caminho)).status, 404);
  }
  assert.equal((await requisitar('/api/inexistente')).status, 404);
});

test('responde erros do repositório sem revelar detalhes da conexão', async (t) => {
  const repo = repositorioEmMemoria();
  repo.listar = async () => { throw new Error('senha-interna-e-host-interno'); };
  const requisitar = await iniciar(t, repo);
  const resposta = await requisitar('/api/alunos');
  assert.equal(resposta.status, 500);
  assert.doesNotMatch(await resposta.text(), /senha-interna/);
});

test('indica disponibilidade e indisponibilidade do banco', async (t) => {
  const repo = repositorioEmMemoria();
  const requisitar = await iniciar(t, repo);
  assert.deepEqual(await (await requisitar('/api/saude')).json(), { status: 'ok', banco: 'conectado' });
  repo.verificarConexao = async () => { throw new Error('ECONNREFUSED'); };
  assert.equal((await requisitar('/api/saude')).status, 503);
});

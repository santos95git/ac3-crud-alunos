import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { randomUUID } from 'node:crypto';
import { criarPool } from '../src/db.js';
import { criarRepositorio } from '../src/repositorio.js';
import { criarApp } from '../src/app.js';

// Execute manualmente na VM com "npm run test:mysql", depois de configurar o banco.
// Cria um registro identificado por UUID e remove somente esse registro ao terminar.
test('CRUD HTTP com persistência real no MySQL', async (t) => {
  const pool = criarPool();
  const email = `teste-${randomUUID()}@example.com`;
  t.after(async () => {
    try { await pool.execute('DELETE FROM alunos WHERE email = ?', [email]); }
    finally { await pool.end(); }
  });
  const repo = criarRepositorio(pool);
  await repo.verificarConexao();
  const servidor = criarApp(repo).listen(0, '127.0.0.1');
  await once(servidor, 'listening');
  t.after(() => new Promise((resolve, reject) => servidor.close((erro) => erro ? reject(erro) : resolve())));
  const base = `http://127.0.0.1:${servidor.address().port}/api/alunos`;
  const enviar = (metodo, dados, id = '') => fetch(`${base}${id ? `/${id}` : ''}`, {
    method: metodo, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(dados),
    signal: AbortSignal.timeout(10000)
  });
  const dados = { nome: 'Aluno de teste AC3', email, curso: 'Redes de Computadores' };
  let resposta = await enviar('POST', dados);
  assert.equal(resposta.status, 201);
  const criado = await resposta.json();
  let [linhas] = await pool.execute('SELECT nome, email, curso FROM alunos WHERE id = ?', [criado.id]);
  assert.equal(linhas.length, 1);
  assert.deepEqual({ ...linhas[0] }, dados);
  assert.equal((await enviar('POST', dados)).status, 409);
  assert.equal((await enviar('PUT', dados, criado.id)).status, 200, 'Salvar valores iguais mantém o aluno existente');
  const atualizados = { ...dados, nome: "João D'Ávila", curso: 'Sistemas de Informação' };
  assert.equal((await enviar('PUT', atualizados, criado.id)).status, 200);
  resposta = await fetch(`${base}/${criado.id}`, { signal: AbortSignal.timeout(10000) });
  assert.deepEqual(await resposta.json(), { id: criado.id, ...atualizados });
  resposta = await fetch(base, { signal: AbortSignal.timeout(10000) });
  assert.ok((await resposta.json()).some((aluno) => aluno.id === criado.id));
  assert.equal((await fetch(`${base}/${criado.id}`, { method: 'DELETE', signal: AbortSignal.timeout(10000) })).status, 204);
  [linhas] = await pool.execute('SELECT id FROM alunos WHERE id = ?', [criado.id]);
  assert.equal(linhas.length, 0);
});

// Os valores são enviados separadamente do SQL por meio de placeholders (?).
// execute() utiliza prepared statements no driver mysql2.
export function criarRepositorio(pool) {
  return {
    async verificarConexao() {
      await pool.execute('SELECT 1');
    },
    async listar() {
      const [linhas] = await pool.execute('SELECT id, nome, email, curso FROM alunos ORDER BY id DESC');
      return linhas;
    },
    async buscar(id) {
      const [linhas] = await pool.execute('SELECT id, nome, email, curso FROM alunos WHERE id = ?', [id]);
      return linhas[0] || null;
    },
    async criar({ nome, email, curso }) {
      const [resultado] = await pool.execute(
        'INSERT INTO alunos (nome, email, curso) VALUES (?, ?, ?)',
        [nome, email, curso]
      );
      return { id: resultado.insertId, nome, email, curso };
    },
    async atualizar(id, { nome, email, curso }) {
      const [resultado] = await pool.execute(
        'UPDATE alunos SET nome = ?, email = ?, curso = ? WHERE id = ?',
        [nome, email, curso, id]
      );
      // O driver usa FOUND_ROWS: affectedRows inclui registros sem alterações.
      return resultado.affectedRows > 0;
    },
    async excluir(id) {
      const [resultado] = await pool.execute('DELETE FROM alunos WHERE id = ?', [id]);
      return resultado.affectedRows > 0;
    }
  };
}

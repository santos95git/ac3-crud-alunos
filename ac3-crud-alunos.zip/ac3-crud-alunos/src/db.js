import mysql from 'mysql2/promise';

export function criarPool(ambiente = process.env) {
  const { DB_HOST = '127.0.0.1', DB_USER = 'ac3_app', DB_PASSWORD, DB_NAME = 'ac3_alunos' } = ambiente;
  const port = Number(ambiente.DB_PORT || 3306);
  if (!DB_PASSWORD || DB_PASSWORD === 'SUBSTITUA_PELA_SENHA_CRIADA_NO_MYSQL') {
    throw new Error('Preencha DB_PASSWORD no arquivo .env com a senha do usuário do MySQL.');
  }
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('DB_PORT deve ser uma porta entre 1 e 65535.');
  }
  return mysql.createPool({
    host: DB_HOST,
    port,
    user: DB_USER,
    password: DB_PASSWORD,
    database: DB_NAME,
    charset: 'utf8mb4',
    waitForConnections: true,
    connectionLimit: 5,
    queueLimit: 20,
    connectTimeout: 5000
  });
}

import express from 'express';
import { fileURLToPath } from 'node:url';

const pastaPublica = fileURLToPath(new URL('../public/', import.meta.url));
const limites = { nome: 120, email: 180, curso: 100 };

function validarAluno(corpo) {
  if (!corpo || typeof corpo !== 'object' || Array.isArray(corpo)) {
    return { erro: 'Envie nome, e-mail e curso em um objeto JSON.' };
  }
  const aluno = {};
  for (const [campo, limite] of Object.entries(limites)) {
    if (typeof corpo[campo] !== 'string') return { erro: `O campo ${campo} é obrigatório.` };
    const valor = corpo[campo].trim();
    if (!valor || [...valor].length > limite) {
      return { erro: `O campo ${campo} deve conter entre 1 e ${limite} caracteres.` };
    }
    aluno[campo] = valor;
  }
  aluno.email = aluno.email.toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(aluno.email)) {
    return { erro: 'Informe um e-mail válido.' };
  }
  return { aluno };
}

export function criarApp(repositorio, { registrarErro = console.error } = {}) {
  const app = express();
  app.disable('x-powered-by');
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
    next();
  });
  app.use(express.json({ limit: '16kb' }));
  app.use('/api', (_req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    next();
  });

  app.get('/api/saude', async (_req, res) => {
    try {
      await repositorio.verificarConexao();
      res.json({ status: 'ok', banco: 'conectado' });
    } catch (erro) {
      registrarErro(erro);
      res.status(503).json({ status: 'erro', erro: 'MySQL indisponível. Confira o serviço e o arquivo .env.' });
    }
  });

  app.get('/api/alunos', async (_req, res) => res.json(await repositorio.listar()));

  app.param('id', (req, res, next, valor) => {
    if (!/^[1-9]\d*$/.test(valor) || Number(valor) > 4294967295) {
      return res.status(400).json({ erro: 'O ID deve ser um inteiro positivo válido.' });
    }
    req.alunoId = Number(valor);
    next();
  });

  app.get('/api/alunos/:id', async (req, res) => {
    const aluno = await repositorio.buscar(req.alunoId);
    if (!aluno) return res.status(404).json({ erro: 'Aluno não encontrado.' });
    res.json(aluno);
  });

  app.post('/api/alunos', async (req, res) => {
    const { aluno, erro } = validarAluno(req.body);
    if (erro) return res.status(400).json({ erro });
    const criado = await repositorio.criar(aluno);
    res.location(`/api/alunos/${criado.id}`).status(201).json(criado);
  });

  app.put('/api/alunos/:id', async (req, res) => {
    const { aluno, erro } = validarAluno(req.body);
    if (erro) return res.status(400).json({ erro });
    const existe = await repositorio.atualizar(req.alunoId, aluno);
    if (!existe) return res.status(404).json({ erro: 'Aluno não encontrado.' });
    res.json({ id: req.alunoId, ...aluno });
  });

  app.delete('/api/alunos/:id', async (req, res) => {
    const excluido = await repositorio.excluir(req.alunoId);
    if (!excluido) return res.status(404).json({ erro: 'Aluno não encontrado.' });
    res.status(204).end();
  });

  app.use('/api', (_req, res) => res.status(404).json({ erro: 'Rota não encontrada.' }));
  app.use(express.static(pastaPublica));
  app.use((_req, res) => res.status(404).type('text').send('Página não encontrada.'));

  // O Express 5 encaminha erros das funções async para este middleware.
  app.use((erro, _req, res, _next) => {
    if (erro.type === 'entity.parse.failed') {
      return res.status(400).json({ erro: 'JSON inválido.' });
    }
    if (erro.type === 'entity.too.large') {
      return res.status(413).json({ erro: 'O conteúdo enviado excede o tamanho permitido.' });
    }
    if (erro.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ erro: 'Já existe um aluno com esse e-mail.' });
    }
    registrarErro(erro);
    return res.status(500).json({ erro: 'Não foi possível concluir a operação. Confira o terminal do servidor.' });
  });
  return app;
}

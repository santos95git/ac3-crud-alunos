-- Opcional: execute depois de 01-banco.sql.
-- Se o e-mail já existir, preserva o registro atual.
USE ac3_alunos;

INSERT INTO alunos (nome, email, curso) VALUES
  ('Ana Souza', 'ana.souza@example.com', 'Análise e Desenvolvimento de Sistemas'),
  ('Bruno Lima', 'bruno.lima@example.com', 'Redes de Computadores'),
  ('Carla Mendes', 'carla.mendes@example.com', 'Sistemas de Informação')
ON DUPLICATE KEY UPDATE id = id;

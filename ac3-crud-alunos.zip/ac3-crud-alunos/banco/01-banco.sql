-- Execute como administrador do MySQL, dentro da VM.
-- O script cria a estrutura sem apagar registros existentes.
CREATE DATABASE IF NOT EXISTS ac3_alunos
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE ac3_alunos;

CREATE TABLE IF NOT EXISTS alunos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(180) NOT NULL,
  curso VARCHAR(100) NOT NULL,
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_alunos_email (email)
) ENGINE=InnoDB;

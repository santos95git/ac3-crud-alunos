# AC3 - Modelo de relato de execução

Preencha os campos depois de executar os testes na sua VM. Este modelo organiza a apresentação dos resultados.

**Aluno(a):** [preencher]

**Integrante da dupla, se houver:** [preencher]

**Sistema operacional da VM:** [preencher]

**Nome da máquina / hostname:** [preencher]

**Versão do Node.js:** [preencher]

**Versão do MySQL:** [preencher]

**Data da execução:** [preencher]

## Objetivo

Executar uma aplicação CRUD de cadastro de alunos, com o servidor Node.js e o banco MySQL instalados na mesma máquina virtual.

## Ambiente e configuração

[Descreva como preparou a VM, instalou as ferramentas, criou o banco `ac3_alunos` e configurou a conexão no `.env`. Informe o usuário de aplicação sem registrar a senha.]

## Resultados dos testes

| Operação | Dados utilizados | Resultado observado | Arquivo da evidência |
| --- | --- | --- | --- |
| Criar | [nome, e-mail e curso fictícios] | [preencher] | [preencher] |
| Consultar | [busca ou recarga da página] | [preencher] | [preencher] |
| Atualizar | [valor anterior e novo valor] | [preencher] | [preencher] |
| Excluir | [registro utilizado] | [preencher] | [preencher] |
| Persistência | [consulta SQL realizada] | [preencher] | [preencher] |

## Conclusão

[Relate se as quatro operações funcionaram, como confirmou a persistência no MySQL e quais ajustes precisou fazer. Se algum teste falhou, registre a falha e o que ficou pendente.]

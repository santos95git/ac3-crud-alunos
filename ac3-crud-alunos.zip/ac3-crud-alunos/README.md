# AC3 - Cadastro de alunos

Exemplo de aplicação CRUD com Node.js, Express e MySQL, elaborado a partir do enunciado da AC3. A aplicação permite cadastrar, listar, buscar na lista, editar e excluir alunos com nome, e-mail e curso.

O pacote contém código e instruções. A criação da VM, a instalação das ferramentas e os prints da execução devem ser feitos no seu computador. Caso o professor exija os fontes disponibilizados no Drive, confira essa orientação antes de usar este exemplo como entrega.

## 1. Prepare a VM

Use uma VM com sistema operacional instalado e interface gráfica, por exemplo Ubuntu Desktop. Instale **MySQL 8 ou superior**, **Node.js 24 ou superior**, **npm** e **VS Code** dentro dessa mesma VM. Abra também o navegador dentro da VM para os testes deste guia.

- Node.js: https://nodejs.org/en/download - escolha uma versão LTS compatível e siga as instruções para o sistema da VM.
- VS Code no Linux: https://code.visualstudio.com/docs/setup/linux
- MySQL no Ubuntu: https://ubuntu.com/server/docs/how-to/databases/install-mysql/

No Ubuntu, instale e inicie o MySQL:

```bash
sudo apt update
sudo apt install -y mysql-server
sudo systemctl enable --now mysql
```

Confira as ferramentas no terminal da VM:

```bash
node --version
npm --version
mysql --version
```

O primeiro comando deve mostrar `v24` ou superior. O Node instalado em versões antigas dos repositórios do sistema pode precisar ser atualizado pelo método indicado no site oficial.

## 2. Abra o projeto no VS Code

Copie o ZIP para a VM e extraia-o. No VS Code, escolha **Arquivo > Abrir Pasta** e selecione `ac3-crud-alunos`. Abra **Terminal > Novo Terminal**. Todos os próximos comandos partem dessa pasta, que contém `package.json` e `server.js`.

## 3. Crie o banco e o usuário

No terminal integrado, importe a estrutura:

```bash
sudo mysql < banco/01-banco.sql
```

Abra o console administrativo do MySQL:

```bash
sudo mysql
```

Execute o SQL abaixo. **Troque `SUA_SENHA_FORTE_AQUI` por uma senha escolhida por você** e anote-a para o `.env`.

```sql
CREATE USER 'ac3_app'@'127.0.0.1' IDENTIFIED BY 'SUA_SENHA_FORTE_AQUI';
GRANT SELECT, INSERT, UPDATE, DELETE ON ac3_alunos.alunos TO 'ac3_app'@'127.0.0.1';
EXIT;
```

Esse usuário acessa o MySQL por TCP em `127.0.0.1` e tem permissão para operar a tabela da aplicação. Execute a criação do usuário uma vez. Se ele já existir, ajuste a senha com:

```sql
ALTER USER 'ac3_app'@'127.0.0.1' IDENTIFIED BY 'SUA_SENHA_FORTE_AQUI';
```

Para carregar três alunos fictícios, execute o script opcional:

```bash
sudo mysql < banco/02-dados-exemplo.sql
```

Se a instalação do MySQL pedir senha administrativa em vez de aceitar `sudo mysql`, use `mysql -u root -p` e informe a senha. Para importar nesse caso: `mysql -u root -p < banco/01-banco.sql`.

## 4. Configure a conexão

Copie o modelo de configuração:

```bash
cp .env.example .env
```

Abra `.env` no VS Code e substitua `DB_PASSWORD` pela mesma senha escolhida no passo anterior:

```dotenv
HOST=127.0.0.1
PORT=3000
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=ac3_app
DB_PASSWORD="SUA_SENHA_FORTE_AQUI"
DB_NAME=ac3_alunos
```

Mantenha a senha entre aspas se ela contiver `#`. Use uma senha sem quebras de linha e escape aspas, se necessário, conforme o formato de arquivos `.env` do Node. O arquivo com sua senha deve permanecer no seu ambiente; o pacote inclui apenas o modelo.

## 5. Instale e execute

```bash
npm install
npm start
```

Com a conexão configurada e o MySQL em execução, o terminal deve mostrar:

```text
MySQL conectado.
Cadastro de alunos: http://127.0.0.1:3000
Pressione Ctrl+C para encerrar.
```

Abra **http://127.0.0.1:3000** no navegador da VM. Mantenha o terminal aberto enquanto usa o sistema. Para encerrar, pressione `Ctrl+C`.

O fluxo é: navegador → HTTP/JSON → Node.js → SQL → MySQL. O navegador acessa a API; o servidor executa as consultas no banco da mesma VM.

## 6. Teste as quatro operações

| Operação | Ação na interface | Resultado esperado |
| --- | --- | --- |
| Criar | Cadastre `João Silva`, `joao.silva@example.com`, `Redes de Computadores`. | Mensagem de sucesso e novo aluno na tabela. |
| Consultar | Busque `João` no campo de busca; depois limpe a busca e recarregue a página. | O cadastro continua disponível após recarregar. |
| Atualizar | Clique em **Editar**, mude o curso para `Sistemas de Informação` e salve. | A tabela passa a mostrar o novo curso. |
| Excluir | Clique em **Excluir** e confirme no diálogo. | O registro sai da tabela e do banco. |

Teste também um e-mail repetido e campos vazios. O sistema deve impedir esses cadastros. A busca filtra os alunos já carregados na página.

Para conferir a persistência diretamente no banco, execute o comando abaixo antes e depois das operações:

```bash
sudo mysql -e "SELECT id, nome, email, curso FROM ac3_alunos.alunos ORDER BY id;"
```

### Testes automáticos

```bash
npm test
```

Executa 10 testes da API com repositório em memória: CRUD, validação, e-mail duplicado, IDs, erros, interface estática e disponibilidade. Esses testes não precisam de MySQL.

Depois de configurar o banco na VM, execute também:

```bash
npm run test:mysql
```

Esse segundo comando testa a API com o MySQL real, verifica os dados persistidos e remove o registro de teste ao terminar. Usa um e-mail exclusivo com UUID e preserva os demais cadastros. O servidor do `npm start` pode permanecer aberto, pois o teste usa outra porta temporária.

## 7. Registre as evidências

Siga o roteiro em `evidencias/ROTEIRO.md`. Faça capturas da sua execução na VM, com a URL e os resultados legíveis. O modelo de relato em `RELATO_EXEMPLO.md` ajuda a organizar as informações depois dos testes.

## Arquivos principais

| Arquivo | Função |
| --- | --- |
| `server.js` | Verifica a conexão e inicia o servidor. |
| `src/app.js` | Define as rotas e valida os dados recebidos. |
| `src/db.js` | Cria o pool de conexões usando o `.env`. |
| `src/repositorio.js` | Executa SELECT, INSERT, UPDATE e DELETE com parâmetros. |
| `public/index.html` | Estrutura da interface. |
| `public/style.css` | Aparência e adaptação para telas menores. |
| `public/app.js` | Comunicação da interface com a API. |
| `banco/01-banco.sql` | Criação do banco e da tabela. |
| `banco/02-dados-exemplo.sql` | Carga opcional com alunos fictícios. |
| `.env.example` | Modelo da configuração local. |
| `test/api.test.js` | Testes HTTP com dados em memória. |
| `test/mysql.test.js` | Teste HTTP com persistência real. |

## Rotas da API

| Método | Rota | Função |
| --- | --- | --- |
| GET | `/api/saude` | Verifica a conexão com o MySQL. |
| GET | `/api/alunos` | Lista os alunos, dos mais recentes para os mais antigos. |
| GET | `/api/alunos/:id` | Consulta um aluno pelo ID. |
| POST | `/api/alunos` | Cria um aluno. |
| PUT | `/api/alunos/:id` | Atualiza nome, e-mail e curso. |
| DELETE | `/api/alunos/:id` | Exclui um aluno. |

POST e PUT recebem, por exemplo:

```json
{
  "nome": "João Silva",
  "email": "joao.silva@example.com",
  "curso": "Redes de Computadores"
}
```

## Problemas comuns

| Problema | Como resolver |
| --- | --- |
| `Access denied for user` | Confira usuário, senha e conta `ac3_app` com host `127.0.0.1`. Compare a senha do `.env` com a criada no MySQL. |
| `ECONNREFUSED` | Inicie o MySQL e confira `DB_HOST` e `DB_PORT`. |
| `Unknown database` ou tabela inexistente | Importe `banco/01-banco.sql` e mantenha `DB_NAME=ac3_alunos`. |
| `Porta em uso` | Encerre outra execução ou altere `PORT` no `.env` e use a nova porta no navegador. |
| Opção `--env-file-if-exists` desconhecida | Instale Node.js 24 ou superior. |
| Arquivo `.env.example` não aparece | Ative a exibição de arquivos ocultos ou crie `.env` manualmente com o conteúdo acima. |
| Duplo clique no HTML não carrega dados | Inicie o servidor e acesse a URL HTTP informada pelo terminal. |

O exemplo foi preparado para uso local na VM e inicia em `127.0.0.1`. Não há autenticação de usuários. Para a atividade, use o navegador da própria VM.

## Referências técnicas

- Express 5: https://expressjs.com/en/5x/api/
- MySQL2 e prepared statements: https://sidorares.github.io/node-mysql2/docs
- Node.js e arquivos de ambiente: https://nodejs.org/api/cli.html#--env-file-if-existsfile
- Contas e permissões no MySQL: https://dev.mysql.com/doc/refman/8.4/en/grant.html

## Verificação realizada neste exemplo

Os 10 testes HTTP passaram e a sintaxe JavaScript foi verificada. A interface ainda precisa ser conferida no navegador da VM. A integração com MySQL não foi executada no ambiente de preparação, que não possui o servidor MySQL instalado; execute `npm run test:mysql` e o roteiro de evidências na sua VM.

# Roteiro de prints da AC3

Capture as telas na VM onde você executou a aplicação e o MySQL. Os nomes abaixo são sugestões para organizar seus próprios arquivos.

| Print | O que mostrar |
| --- | --- |
| `01-vm-ferramentas.png` | Janela da VM e terminal com `node --version`, `npm --version`, `mysql --version` e `hostname`. |
| `02-banco-tabela.png` | MySQL com `SHOW DATABASES;`, `USE ac3_alunos;`, `SHOW TABLES;` e `DESCRIBE alunos;`. |
| `03-execucao.png` | VS Code aberto na pasta e terminal com `npm start`, conexão confirmada e endereço da aplicação. |
| `04-criar-consultar.png` | Navegador com URL visível, novo aluno listado e confirmação do cadastro. |
| `05-atualizar.png` | Aluno com curso alterado e mensagem de atualização. |
| `06-excluir.png` | Lista após excluir o aluno e mensagem de exclusão. |
| `07-persistencia.png` | Consulta `SELECT id, nome, email, curso FROM ac3_alunos.alunos;` mostrando os dados de um cadastro de teste mantido no banco. |

Para mostrar a persistência, mantenha um aluno fictício e recarregue a página antes de capturar o print 07. Use outro aluno para demonstrar a exclusão.

Opcional: registre `npm test` e `npm run test:mysql` aprovados na VM.

Antes de enviar, confira se as telas estão legíveis e não exibem sua senha. Identifique seu nome e, se for em dupla, o nome do colega conforme a orientação do professor. Preencha o relato somente com ações e resultados que você realizou.

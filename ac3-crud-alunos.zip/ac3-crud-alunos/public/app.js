const $ = (id) => document.getElementById(id);
const form = $('form-aluno');
let alunos = [];
let idEdicao = null;
let idExclusao = null;
let ocupado = false;
let carregamento = 0;

function mensagem(texto, erro = false) {
  $('mensagem').textContent = texto;
  $('mensagem').className = `message${erro ? ' error' : ''}`;
  $('mensagem').hidden = !texto;
}

async function api(caminho, opcoes = {}) {
  const resposta = await fetch(`/api${caminho}`, {
    ...opcoes,
    headers: { 'Content-Type': 'application/json', ...opcoes.headers }
  });
  const dados = resposta.status === 204 ? null : await resposta.json();
  if (!resposta.ok) throw new Error(dados?.erro || 'Não foi possível concluir a operação.');
  return dados;
}

async function verificarConexao() {
  try {
    await api('/saude');
    $('conexao').textContent = 'MySQL conectado';
    $('conexao').className = 'connection online';
  } catch {
    $('conexao').textContent = 'MySQL indisponível';
    $('conexao').className = 'connection offline';
  }
}

function desenharLista() {
  const termo = $('busca').value.trim().toLocaleLowerCase('pt-BR');
  const visiveis = alunos.filter((aluno) => [aluno.nome, aluno.email, aluno.curso]
    .some((valor) => valor.toLocaleLowerCase('pt-BR').includes(termo)));
  $('total').textContent = alunos.length;
  $('resumo-lista').textContent = `${visiveis.length} de ${alunos.length} registro(s)`;
  $('alunos').replaceChildren();
  for (const aluno of visiveis) {
    const linha = document.createElement('tr');
    const identificacao = document.createElement('td');
    const nome = document.createElement('span');
    nome.className = 'student-name';
    nome.textContent = aluno.nome;
    const email = document.createElement('span');
    email.className = 'student-email';
    email.textContent = aluno.email;
    identificacao.append(nome, email);
    const curso = document.createElement('td');
    curso.textContent = aluno.curso;
    const acoes = document.createElement('td');
    const grupo = document.createElement('div');
    grupo.className = 'actions';
    for (const [rotulo, acao, classe] of [['Editar', editar, ''], ['Excluir', confirmarExclusao, ' delete']]) {
      const botao = document.createElement('button');
      botao.type = 'button';
      botao.className = `action${classe}`;
      botao.textContent = rotulo;
      botao.setAttribute('aria-label', `${rotulo} ${aluno.nome}`);
      botao.disabled = ocupado;
      botao.addEventListener('click', () => acao(aluno));
      grupo.append(botao);
    }
    acoes.append(grupo);
    linha.append(identificacao, curso, acoes);
    $('alunos').append(linha);
  }
  $('vazio').hidden = visiveis.length > 0;
  $('vazio').querySelector('h3').textContent = termo ? 'Nenhum resultado encontrado' : 'Nenhum aluno por aqui';
  $('vazio').querySelector('p').textContent = termo ? 'Experimente buscar por outro nome, e-mail ou curso.' : 'Use o formulário para criar o primeiro cadastro.';
}

async function carregarAlunos() {
  const versao = ++carregamento;
  try {
    const resposta = await api('/alunos');
    if (versao !== carregamento) return;
    alunos = resposta;
    desenharLista();
  } catch (erro) {
    if (versao !== carregamento) return;
    $('resumo-lista').textContent = 'Não foi possível atualizar a lista.';
    mensagem(erro.message, true);
  }
}

function limparFormulario() {
  idEdicao = null;
  form.reset();
  $('form-titulo').textContent = 'Novo aluno';
  $('form-ajuda').textContent = 'Preencha todos os campos para cadastrar.';
  $('salvar').replaceChildren(document.createTextNode('Cadastrar aluno '));
  const seta = document.createElement('span');
  seta.setAttribute('aria-hidden', 'true');
  seta.textContent = '↗';
  $('salvar').append(seta);
  $('cancelar').hidden = true;
}

function editar(aluno) {
  if (ocupado) return;
  idEdicao = aluno.id;
  for (const campo of ['nome', 'email', 'curso']) $(campo).value = aluno[campo];
  $('form-titulo').textContent = 'Editar aluno';
  $('form-ajuda').textContent = `Editando o cadastro #${aluno.id}.`;
  $('salvar').textContent = 'Salvar alterações';
  $('cancelar').hidden = false;
  mensagem('');
  $('nome').focus();
}

function bloquear(valor) {
  ocupado = valor;
  for (const elemento of form.elements) elemento.disabled = valor;
  $('atualizar').disabled = valor;
  $('excluir-confirmado').disabled = valor;
  $('voltar').disabled = valor;
  desenharLista();
}

form.addEventListener('submit', async (evento) => {
  evento.preventDefault();
  if (ocupado) return;
  const dados = Object.fromEntries(new FormData(form));
  const editando = idEdicao !== null;
  const caminho = editando ? `/alunos/${idEdicao}` : '/alunos';
  bloquear(true);
  try {
    await api(caminho, { method: editando ? 'PUT' : 'POST', body: JSON.stringify(dados) });
    limparFormulario();
    $('busca').value = '';
    mensagem(editando ? 'Cadastro atualizado com sucesso.' : 'Aluno cadastrado com sucesso.');
    await carregarAlunos();
  } catch (erro) {
    mensagem(erro.message, true);
  } finally {
    bloquear(false);
    void verificarConexao();
  }
});

function confirmarExclusao(aluno) {
  if (ocupado) return;
  idExclusao = aluno.id;
  $('excluir-texto').textContent = `O cadastro de ${aluno.nome} será excluído. Esta ação remove o registro do banco.`;
  $('confirmacao').showModal();
}

$('voltar').addEventListener('click', () => $('confirmacao').close());
$('confirmacao').addEventListener('cancel', (evento) => { if (ocupado) evento.preventDefault(); });
$('confirmacao').addEventListener('close', () => { idExclusao = null; });
$('excluir-confirmado').addEventListener('click', async () => {
  if (ocupado || idExclusao === null) return;
  const id = idExclusao;
  bloquear(true);
  try {
    await api(`/alunos/${id}`, { method: 'DELETE' });
    if (idEdicao === id) limparFormulario();
    $('confirmacao').close();
    mensagem('Aluno excluído com sucesso.');
    await carregarAlunos();
  } catch (erro) {
    $('confirmacao').close();
    mensagem(erro.message, true);
  } finally {
    bloquear(false);
    void verificarConexao();
  }
});

$('cancelar').addEventListener('click', () => { limparFormulario(); mensagem(''); });
$('busca').addEventListener('input', desenharLista);
$('atualizar').addEventListener('click', async () => {
  mensagem('');
  $('atualizar').disabled = true;
  try { await Promise.all([carregarAlunos(), verificarConexao()]); }
  finally { $('atualizar').disabled = ocupado; }
});
void Promise.all([carregarAlunos(), verificarConexao()]);
